import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {

        int[] numeros = new int[20];

        for (int i = 0; i < numeros.length; i++) {
            int numeroAleatorio = (int) (Math.random() * 21 + 20);

            numeros[i] = numeroAleatorio;

        }
        try (DataOutputStream dos = new DataOutputStream(
                new BufferedOutputStream(
                        new FileOutputStream("numeros.dat")))) {

            for (int i = 0; i < numeros.length; i++) {

                dos.writeInt(numeros[i]);

            }


        } catch (IOException ex) {
            ex.printStackTrace();
        }
        try (BufferedWriter bw = new BufferedWriter(
                new FileWriter("numeros.txt"))) {

            for (int i = 0; i < numeros.length; i++) {
                bw.write(String.valueOf(numeros[i]));
                bw.newLine();
            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }


    }
}